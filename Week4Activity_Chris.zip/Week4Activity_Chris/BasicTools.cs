﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week4Activity_Chris
{
    class BasicTools
    {
        public static void Pause()
        {
            Console.WriteLine("\nPress Any Key to continue...");
            Console.ReadKey();
        }
    }
}
