﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Chris
{
    class Program
    {
        static void Main(string[] args)
        {
            String fname, lname, name, hour, hourlyRate;
            Int32 intHour, intRate, gross, taxPay, net;
            Double dblResult, tax;
            int payrollNum = 0;
            List<string> nameList = new List<string>();
            List<double> grossList = new List<double>();
            List<double> taxList = new List<double>();
            List<double> netList = new List<double>();






            Console.WriteLine("\tHello!\n\n");

            Console.Write("How many payrolls do you need to enter? ");
            payrollNum = int.Parse(Console.ReadLine());

            for (int cntr = 1; cntr <= payrollNum; cntr++)
            {

                Console.Write("\nPlease enter the first name: ");
                fname = Console.ReadLine();

                Console.Write("\nPlease enter the last name: ");
                lname = Console.ReadLine();

                name = fname + ' ' + lname;
                //Console.Write(name);
                nameList.Add(name);

                //Console.WriteLine(name);

                Console.Write("\nPlease enter the amount of hours worked: ");
                hour = Console.ReadLine();

                //Console.WriteLine(hour);

                Console.Write("\nPlease enter your hourly rate: ");
                hourlyRate = Console.ReadLine();

                intHour = Convert.ToInt32(hour);
                intRate = Convert.ToInt32(hourlyRate);
                gross = intHour * intRate;

                grossList.Add(gross);
                //Console.WriteLine(gross);


                if (gross >= 0 && gross <= 499)
                {
                    tax = 0.2;
                }

                else if (gross >= 500 && gross <= 999)
                {
                    tax = 0.3;
                }

                else if (gross >= 1000)
                {
                    tax = 0.5;
                }

                else
                {
                    tax = 0;
                }


                taxPay = (int)(gross * tax);
                taxList.Add(taxPay);
                //Console.WriteLine(taxPay);


                net = gross - taxPay;
                netList.Add(net);

                Console.Clear();
            }

            for (int cntr = 0; cntr < payrollNum; cntr++)
            {
                Console.Write($"\n\n{nameList[cntr]}'s Payroll Info\n");
                Console.Write("---------------------------------\n");
                Console.Write($"Gross pay: ${grossList[cntr]}\n");
                Console.Write($"Taxes due: ${taxList[cntr]}\n");
                Console.Write($"Total net pay: ${netList[cntr]}\n");
                Console.Write("---------------------------------\n");
            }










            Console.Write("\n\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}
